# Kubernetes HA (3 masters + 3 workers) con Vagrant + Hyper‑V (Windows 11)
**LAN:** `10.10.100.0/25` (vSwitch externo `net-vms`, DHCP)  
**VIP API (kube-vip):** `10.10.100.120`  
**MetalLB (L2):** `10.10.100.110–10.10.100.119`  
**Ubuntu 22.04**, **containerd**, **kubeadm**, **Calico** (CNI), **local-path** (StorageClass default)

## Archivos incluidos
- `Vagrantfile` → **Híbrido** (DHCP por `net-vms` + red interna fija 192.168.56.x para join robusto).
- `Vagrantfile.dhcp-only` → **Solo DHCP** (joins vía VIP `10.10.100.120`).
- `post-install.sh` → MetalLB + StorageClass + tests.
- `calico-mtu-auto.sh` → Ajuste automático de MTU para Calico.
- `ingress-nginx-setup.sh` → Instala Ingress NGINX y fija una IP de MetalLB (por defecto `10.10.100.118`).
- `ingress-example.yaml` → Ingress de ejemplo (host nip.io).
- `README.md` → Esta guía.

> Recomendado: reservá `10.10.100.120` (VIP) y el pool `10.10.100.110–119` fuera del DHCP.

## Levantar el cluster
```powershell
$env:VAGRANT_DEFAULT_PROVIDER="hyperv"
# Elegí uno de los Vagrantfile:
# 1) Híbrido: dejá 'Vagrantfile' como está
# 2) Solo DHCP: renombrá 'Vagrantfile.dhcp-only' a 'Vagrantfile'
vagrant up
```

## Post‑install (MetalLB + Storage)
```bash
vagrant ssh m1
./post-install.sh
```

## Ingress NGINX con IP fija de MetalLB
```bash
chmod +x ingress-nginx-setup.sh
./ingress-nginx-setup.sh                      # usa 10.10.100.118 por defecto
# o elegir otra IP del pool:
INGRESS_LB_IP=10.10.100.115 ./ingress-nginx-setup.sh
```
Prueba rápida (nip.io):
```bash
curl -H "Host: echo.10-10-100-118.nip.io" http://10.10.100.118
```

## Kubeconfig en Windows (opcional)
```powershell
New-Item -ItemType Directory $HOME\.kube -Force | Out-Null
vagrant ssh m1 -c "sudo cat /home/vagrant/.kube/config" > $HOME\.kube\config
```

## Troubleshooting
- VIP no responde → revisar pods `kube-vip` en `kube-system`.
- LB sin EXTERNAL-IP → `kubectl -n metallb-system logs deploy/controller`.
- Pods con red rara → `./calico-mtu-auto.sh` y recrear pods.
