#!/usr/bin/env bash
# ingress-nginx-setup.sh - Instala Ingress NGINX y asigna una IP fija de MetalLB
set -euo pipefail
: "${INGRESS_LB_IP:=10.10.100.118}"   # Elegí una IP libre del pool 10.10.100.110-119
: "${CREATE_EXAMPLE:=true}"
need(){ command -v "$1" >/dev/null 2>&1 || { echo "ERROR: falta '$1'"; exit 1; }; }
need kubectl; need curl
echo "== Ingress NGINX + MetalLB (IP fija: ${INGRESS_LB_IP}) =="
if ! kubectl get ns ingress-nginx >/dev/null 2>&1; then
  echo "[1/4] Instalando ingress-nginx (manifiesto oficial)..."
  kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/main/deploy/static/provider/cloud/deploy.yaml
else
  echo "[1/4] Namespace ingress-nginx ya existe, continuando..."
fi
echo "[2/4] Esperando despliegue ingress-nginx-controller..."
kubectl -n ingress-nginx rollout status deploy/ingress-nginx-controller --timeout=5m || true
echo "[3/4] Configurando Service LoadBalancer con IP ${INGRESS_LB_IP}..."
kubectl -n ingress-nginx patch svc ingress-nginx-controller --type merge -p "$(cat <<EOF
{
  "spec": {
    "type": "LoadBalancer",
    "loadBalancerIP": "${INGRESS_LB_IP}",
    "externalTrafficPolicy": "Local"
  }
}
EOF
)" || true
kubectl -n ingress-nginx get svc ingress-nginx-controller -o wide
if [ "${CREATE_EXAMPLE}" = "true" ]; then
  echo "[4/4] Creando ejemplo (deployment echo + service + ingress) ..."
  kubectl apply -f - <<'YAML'
apiVersion: apps/v1
kind: Deployment
metadata: { name: echo }
spec:
  replicas: 1
  selector: { matchLabels: { app: echo } }
  template:
    metadata: { labels: { app: echo } }
    spec:
      containers:
      - name: echo
        image: hashicorp/http-echo
        args: ["-text=hola desde nginx-ingress"]
        ports: [{ containerPort: 5678 }]
---
apiVersion: v1
kind: Service
metadata: { name: echo }
spec:
  selector: { app: echo }
  ports:
  - name: http
    port: 80
    targetPort: 5678
YAML
  HOST="echo.${INGRESS_LB_IP//./-}.nip.io"
  cat > /tmp/ingress-example.yaml <<EOF
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: echo-ingress
  annotations:
    nginx.ingress.kubernetes.io/ssl-redirect: "false"
spec:
  ingressClassName: nginx
  rules:
  - host: \${HOST}
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: echo
            port:
              number: 80
EOF
  kubectl apply -f /tmp/ingress-example.yaml
  echo "Probar:"
  echo "  curl -H 'Host: \${HOST}' http://${INGRESS_LB_IP}"
  echo "  # o http://\${HOST} (si nip.io resuelve en tu red)"
fi
echo "Listo."
